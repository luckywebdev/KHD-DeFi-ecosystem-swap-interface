# 🥞 KHDSwap UIkit

[![Version](https://img.shields.io/npm/v/@KHDSwap-libs/uikit)](https://www.npmjs.com/package/@KHDSwap-libs/uikit) [![Size](https://img.shields.io/bundlephobia/min/@KHDSwap-libs/uikit)](https://www.npmjs.com/package/@KHDSwap-libs/uikit)

KHDSwap UIkit is a set of React components and hooks used to build pages on KHDSwap's apps. It also contains a theme file for dark and light mode.

## Install

`yarn add @KHDSwap-libs/uikit`

## Setup

### Theme

Before using KHDSwap UIkit, you need to provide the theme file to styled-component.

```
import { ThemeProvider } from 'styled-components'
import { light, dark } from '@KHDSwap-libs/uikit'
...
<ThemeProvider theme={isDark}>...</ThemeProvider>
```

### Reset

A reset CSS is available as a global styled component.

```
import { ResetCSS } from '@KHDSwap-libs/uikit'
...
<ResetCSS />
```

### Types

This project is built with Typescript and export all the relevant types.

## How to use the UIkit

If you want to use components from the UIkit, check the [Storybook documentation](https://KHDSwap.github.io/KHDSwap-uikit/)
